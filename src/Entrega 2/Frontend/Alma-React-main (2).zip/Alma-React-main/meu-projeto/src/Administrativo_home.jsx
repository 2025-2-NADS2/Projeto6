import React, { useState } from 'react';
import './codigo_css/Administrativo_home.css'

// Subcomponente para os formulários de Adicionar/Atualizar
const FormSection = ({ title, bgColor, onSubmit, buttonText }) => {
    const [id, setId] = useState('');
    const [titulo, setTitulo] = useState('');
    const [descricao, setDescricao] = useState('');
    const [imageFile, setImageFile] = useState(null);

    const handleSubmit = (e) => {
        e.preventDefault();
        // Lógica de envio (Adicionar/Atualizar) para o backend
        console.log(`${title} - Dados Enviados:`, { id, titulo, descricao, imageFile });
        // Simulação de chamada de API:
        // onSubmit({ id, titulo, descricao, imageFile });
    };

    return (
        <section className={`sec-adcn ${bgColor}`}>
            <h2 className="titulo-adcn">{title}</h2>
            <form onSubmit={handleSubmit}>
                <div className="mb-4">
                    <label htmlFor={`${title}-id`} className="campo-id">ID</label>
                    <input 
                        type="text"     
                        id={`${title}-id`} 
                        value={id}
                        onChange={(e) => setId(e.target.value)}
                        className="campo-titulo"
                    />
                </div>
                <div className="mb-4">
                    <label htmlFor={`${title}-titulo`} className="block text-sm font-medium text-gray-700 mb-1">Titulo</label>
                    <input 
                        type="text" 
                        id={`${title}-titulo`} 
                        value={titulo}
                        onChange={(e) => setTitulo(e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                    />
                </div>
                <div className="mb-4">
                    <label htmlFor={`${title}-descricao`} className="block text-sm font-medium text-gray-700 mb-1">Descrição da atividade</label>
                    <textarea 
                        id={`${title}-descricao`} 
                        rows="4"
                        value={descricao}
                        onChange={(e) => setDescricao(e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                    ></textarea>
                </div>
                
                {/* Botões de Ação */}
                <div className="upload">
                    <label className="upload-btn">
                        Upload Imagem
                        <input 
                            type="file" 
                            className="hidden"
                            onChange={(e) => setImageFile(e.target.files[0])}
                        />
                    </label>
                    
                    <div className="botoes">
                        {/* Botão Adicionar */}
                        <button type="submit" className="btn-adcn">
                            Adicionar
                        </button>
                        {/* Botão Atualizar */}
                        <button type="button" className="btn-atlz">
                            Atualizar
                        </button>
                        {/* Botão Excluir */}
                        <button type="button" className="btn-excl">
                            Excluir
                        </button>
                    </div>
                </div>
            </form>
        </section>
    );
};

// Subcomponente Fale Conosco
const FaleConoscoSection = () => {
    const [message, setMessage] = useState('');

    return (
        <section className="bg-slate-700 p-6 md:p-8 rounded-lg shadow-xl">
            <h2 className="text-xl font-semibold mb-6 text-white">Fale Conosco</h2>
            <form>
                <div>
                    <textarea 
                        rows="8" 
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        className="campo-faleConosco" 
                        placeholder="Digite sua mensagem..."
                    ></textarea>
                </div>
            </form>
        </section>
    );
};


const AdminPanel = () => {
    return (
        <div className="min-h-screen bg-gray-50 p-4 md:p-8">
            <div className="container mx-auto max-w-4xl">
                
                {/* Título Principal */}
                <h1 className="text-3xl font-extrabold text-center mb-10 text-gray-800 tracking-wider">ADMINISTRADOR</h1>

                {/* Seção 1: Adicionar Atividade (Verde-água) */}
                <FormSection
                    title="Adicionar Atividade"
                    bgColor="bg-teal-100" // Cor semelhante à da imagem
                    onSubmit={(data) => console.log("Adicionar Atividade:", data)}
                />

                {/* Seção 2: Atualizar Evento (Rosa) */}
                <FormSection
                    title="Atualizar Evento"
                    bgColor="bg-pink-100" // Cor semelhante à da imagem
                    onSubmit={(data) => console.log("Atualizar Evento:", data)}
                />

                {/* Seção 3: Fale Conosco (Azul-escuro) */}
                <FaleConoscoSection />

            </div>
        </div>
    );
};

export default AdminPanel;