import React, { useEffect, useState } from "react";
import './codigo_css/Doador.css'
import doadorBanner from './assets/image/doador1_img.png'
import doador2 from './assets/image/doador2.png'
// import atv1 from './assets/image/atv_exemplo1.png'
// import atv2 from './assets/image/atv_exemplo2.png'
// import atv3 from './assets/image/atv_exemplo3.png'
// import atv4 from './assets/image/atv_exemplo4.png'

// function Doador(){
//     const [doador, setDoadores] = useState([]);

//     useEffect(() => {
//       fetch("http://localhost:3000/api/doadores") // backend rodando na porta 3000
//         .then((res) => res.json())
//         .then((data) => setDoadores(data))
//         .catch((err) => console.error(err));
//     }, []);



//     return(
//         <main>
//             <h1 className="doador-titulo">Lista de Usuários:</h1>
//             <section className="doador-lista">
//                  <ul>
//                     {doador.map((u,i) =>(
//                         <li key={i}>
//                             <div>Nome: {u.nome}</div> 
//                             <span>Email: {u.email}</span>
//                         </li>
//                     )
//                     )}
//                 </ul>  
//             </section>
//         </main>
//     )
// }
// export default Doador;

//REFAZENDO A TELA DE DOADOR, SE PRECISAR VOLTAR A ANTIGA SÓ COMENTAR O CÓDIGO ABAIXO E DESCOMENTAR O DE CIMA

function Doador(){

    const donationCards = [
        { amount: 50, description: "Garante 10 refeições nutritivas da Sopa Fraterna." },
        { amount: 100, description: "Garante 20 refeições completas e nutritivas." },
        { amount: 150, description: "Ajuda a custear o enxoval de um bebê no Projeto Crê.Ser." },
        { amount: 300, description: "Apoia uma família com alimento por um mês (cesta básica + apoio)." },
    ];

    return(
        <main>
            <div>
                <img src={doadorBanner} alt="foto da equipe de cozinha Alma" />
                <h1>Doar</h1>
            </div>

            <section className='home-section3 home-section3-sobre'>
                <article>
                <h1>Por Que Doar ao Instituto Alma?</h1>
                        <p>

                        No Instituto Alma, sua doação vai além do auxílio material; ela se transforma em dignidade, acolhimento e experiências únicas. Acreditamos que a verdadeira mudança acontece ao tocar o coração e levar a esperança a quem mais precisa.

                        </p>
                </article>
                <img src={doador2} alt="exemplo" />
            </section>

            <section className="secPrincipios">
                <h1>SUA DOAÇÃO É O MOTOR DA MUDANÇA! </h1>
                <div>
                    <article>
                        {/* <img src={doador3} alt="Icone de um avião" /> */}
                        <h2>10.000 Refeições por Mês</h2>
                        <p>
                            Alimento nutritivo e preparado com carinho para famílias em 5 comunidades.
                        </p>
                    </article>

                    <article>
                        {/* <img src={principio2} alt="Um olho" /> */}
                        <h2>Natal Inesquecível</h2>
                        <p>
                            A chance de 2.500 crianças escolherem seus próprios presentes no Projeto Natal de Amor.
                        </p>
                    </article>

                    <article>
                        {/* <img src={principio3} alt="Icone de coração" /> */}
                        <h2>Acompanhamento Materno</h2>
                        <p>
                            Suporte e enxovais para gestantes em extrema vulnerabilidade através do Projeto Crê.Ser.
                        </p>
                    </article>
                </div>
            </section>

            <section className="secPresidente">
                {/* <img src={sobrePresidente} alt="Presidente do istituto alma" /> */}
        
                    <div className="textoPresidente">
                        <h1>PALAVRAS DO PRESIDENTE</h1>
                        <p>
                            "Nosso propósito no Instituto Alma vai além de suprir a carência material; é resgatar a dignidade humana. Acreditamos que todos merecem viver momentos de encantamento. Cada refeição que entregamos, cada presente que uma criança escolhe no Natal e cada enxoval para uma gestante são ações de amor. É um compromisso de impactar o coração de quem mais precisa, mostrando que a vida pode e deve ser especial, com apoio e solidariedade." <span className="textoDestaque"><br />Silvio Luiz Lemos Silva <br />Presidente do Instituto Alma</span>
                        </p>
                    </div>
            </section>

            <section className="doador-banner-section">
                <div className="doador-banner-overlay">
                    <div className="doador-banner-content">
                        {/* Título e Subtítulo */}
                        <h1 className="doador-banner-title">Agora, sua doação transforma Vidas!</h1>
                        <p className="doador-banner-subtitle">Escolha sua doação:</p>
                        
                        {/* Container dos Cartões */}
                        <div className="donation-cards-wrapper">
                            {donationCards.map((card, index) => (
                                <div key={index} className="donation-card">
                                    <span className="card-amount">R$ {card.amount}</span>
                                    <p className="card-description">{card.description}</p>
                                    <button className="btn-doe-agora">Doe Agora</button>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
                {/* Imagem de fundo é aplicada via CSS no .doador-banner-section */}
            </section>

        </main>
    );
}

export default Doador;