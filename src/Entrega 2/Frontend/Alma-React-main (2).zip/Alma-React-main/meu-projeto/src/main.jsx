import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './codigo_css/index.css'
import { BrowserRouter } from "react-router-dom";
import App from './App.jsx'

createRoot(document.getElementById('root')).render(
    <BrowserRouter>
      <App />
    </BrowserRouter>
)
